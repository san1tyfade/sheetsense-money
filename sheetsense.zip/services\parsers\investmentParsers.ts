/**
 * @deprecated
 * Functional logic moved to services/parsers/UniversalParser.ts
 * This file is retained for path compatibility during current refactor cycle.
 */
export {};
