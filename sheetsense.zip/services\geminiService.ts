/**
 * @deprecated
 * Functional logic moved to services/infrastructure/IntelligenceProvider.ts
 * This file is retained for path compatibility during current refactor cycle.
 */
export {};
